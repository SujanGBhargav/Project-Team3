package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Passenger;

import com.example.demo.repository.PassengerRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class PassengerController {
	
	@Autowired
	PassengerRepository passengerRepository;
	@PostMapping("/addpassenger")
	public ResponseEntity<Passenger> createUser(@RequestBody Passenger p)
	{
		
		try
		{
	   	   Passenger	_passenger= passengerRepository.save(new Passenger(p.getName(),p.getGender(),p.getAge()));
	       return new ResponseEntity<>(_passenger,HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/allpassengers")
	public ResponseEntity<List<Passenger>> getAllUsers()
	{
		
		try
		{
	   	   List<Passenger> passenger_=new ArrayList<Passenger>();
	   	   passengerRepository.findAll().forEach(passenger_::add);
	       return new ResponseEntity<>(passenger_,HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/getpassenger/{pid}")
	public ResponseEntity<Passenger> getUserById(@PathVariable("pid") int pid)
	{
		
		
			Optional<Passenger> passData=passengerRepository.findById(pid);
			if(passData.isPresent()) {
				 return new ResponseEntity<>(passData.get(), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		
			
	}
	
	@PutMapping("/updatepassenger/{pid}")
	public ResponseEntity<Passenger> updateUser(@PathVariable("pid") int pid,@RequestBody Passenger p)
	{
		
		
			Optional<Passenger> passData=passengerRepository.findById(pid);
			if(passData.isPresent()) {
				Passenger _passenger=passData.get();
				_passenger.setName(p.getName());
				_passenger.setGender(p.getGender());
				_passenger.setAge(p.getAge());
				
				 return new ResponseEntity<>(passengerRepository.save(_passenger), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		
			
	} 
	
	@DeleteMapping("/deletepassenger/{pid}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("pid") int pid){
		
		try
		{
			passengerRepository.deleteById(pid);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	

}
